from odoo import http
from odoo.http import request

from ..models.dental_event_request import TREATMENT_INTERESTS


class DentistClinicEventRequest(http.Controller):

    def _closed_response(self):
        return request.make_json_response({'success': False, 'error': 'Talep formu şu anda kapalı.'})

    @http.route('/dentistclinic/event-request/countries', type='http', auth='public',
                methods=['GET'], website=True, sitemap=False)
    def event_request_countries(self, **kwargs):
        if not request.website.company_id.dentistclinic_health_tourism_enabled:
            return self._closed_response()
        countries = request.env['res.country'].sudo().search([], order='name')
        return request.make_json_response({
            'success': True,
            'countries': [{'id': c.id, 'name': c.name} for c in countries],
        })

    @http.route('/dentistclinic/event-request/submit', type='http', auth='public',
                methods=['POST'], website=True, csrf=True, sitemap=False)
    def event_request_submit(self, **post):
        company = request.website.company_id
        if not company.dentistclinic_health_tourism_enabled:
            return self._closed_response()

        success = {
            'success': True,
            'message': 'Talebiniz alındı. Bölgenizde bir danışma günü planlandığında sizi bilgilendireceğiz.',
        }
        # Gizli tuzak alanı: insanlar görmez, botlar doldurur. Bota başarılı
        # görünür ama kayıt oluşturulmaz.
        if post.get('website_url'):
            return request.make_json_response(success)

        contact_name = (post.get('contact_name') or '').strip()[:140]
        phone = (post.get('phone') or '').strip()[:32]
        email = (post.get('email') or '').strip()[:140]
        city = (post.get('city') or '').strip()[:100]
        notes = (post.get('notes') or '').strip()[:2000]
        treatment_interest = post.get('treatment_interest') or False
        if treatment_interest not in dict(TREATMENT_INTERESTS):
            treatment_interest = False

        if not contact_name or not city:
            return request.make_json_response({'success': False, 'error': 'Ad soyad ve şehir zorunludur.'})
        if not phone and not email:
            return request.make_json_response({'success': False, 'error': 'Telefon veya e-posta bilgilerinden en az birini girin.'})
        if not post.get('privacy_consent'):
            return request.make_json_response({'success': False, 'error': 'Devam etmek için KVKK aydınlatma metnini onaylamanız gerekir.'})
        try:
            country = request.env['res.country'].sudo().browse(int(post.get('country_id') or 0)).exists()
        except ValueError:
            country = None
        if not country:
            return request.make_json_response({'success': False, 'error': 'Lütfen ülke seçin.'})

        request.env['dental.event.request']._create_from_website({
            'contact_name': contact_name,
            'phone': phone or False,
            'email': email or False,
            'country_id': country.id,
            'city': city,
            'treatment_interest': treatment_interest,
            'notes': notes,
            'lang': request.lang.code if request.lang else False,
            'company_id': company.id,
        })
        return request.make_json_response(success)
