/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.DentistClinicEventRequest = publicWidget.Widget.extend({
    selector: ".s_dental_event_request",
    events: {
        "submit .dental-event-request-form": "_onSubmit",
    },

    async start() {
        this.form = this.el.querySelector(".dental-event-request-form");
        this.statusEl = this.el.querySelector(".dental-appointment-status");
        this.submitButton = this.el.querySelector(".dental-event-request-submit");
        this.countrySelect = this.form.querySelector("select[name='country_id']");
        await this._super(...arguments);
        await this._loadCountries();
    },

    async _loadCountries() {
        let result;
        try {
            const response = await fetch("/dentistclinic/event-request/countries", {
                headers: { Accept: "application/json" },
            });
            result = await response.json();
        } catch {
            result = { success: false, error: "Bağlantı hatası, lütfen sayfayı yenileyin." };
        }
        this.countrySelect.replaceChildren(this._option("", result.success ? "Ülke seçin" : "-"));
        if (!result.success) {
            this._setStatus("is-error", result.error);
            this.submitButton.disabled = true;
            return;
        }
        for (const country of result.countries) {
            this.countrySelect.appendChild(this._option(country.id, country.name));
        }
    },

    _validate() {
        const els = this.form.elements;
        if (!els.country_id.value) {
            return "Lütfen ülke seçin.";
        }
        if (!els.city.value.trim() || !els.contact_name.value.trim()) {
            return "Ad soyad ve şehir zorunludur.";
        }
        if (!els.phone.value.trim() && !els.email.value.trim()) {
            return "Telefon veya e-posta bilgilerinden en az birini girin.";
        }
        if (els.email.value.trim() && !els.email.checkValidity()) {
            return "Geçerli bir e-posta adresi girin.";
        }
        if (!els.privacy_consent.checked) {
            return "Devam etmek için KVKK aydınlatma metnini onaylamanız gerekir.";
        }
        return "";
    },

    async _onSubmit(ev) {
        ev.preventDefault();
        const error = this._validate();
        if (error) {
            this._setStatus("is-error", error);
            return;
        }
        this.submitButton.disabled = true;
        this._setStatus("", "");
        const formData = new FormData(this.form);
        if (odoo.csrf_token) {
            formData.append("csrf_token", odoo.csrf_token);
        }
        try {
            const response = await fetch("/dentistclinic/event-request/submit", {
                method: "POST",
                body: formData,
                headers: { Accept: "application/json" },
            });
            const result = await response.json();
            if (result.success) {
                this.form.reset();
                this._setStatus("is-success", result.message);
            } else {
                this._setStatus("is-error", result.error || "Talebiniz gönderilemedi.");
            }
        } catch {
            this._setStatus("is-error", "Talebiniz gönderilemedi, lütfen tekrar deneyin.");
        } finally {
            this.submitButton.disabled = false;
        }
    },

    _option(value, label) {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = label;
        return option;
    },

    _setStatus(statusClass, message) {
        this.statusEl.className = "dental-appointment-status";
        if (!message) {
            this.statusEl.classList.add("d-none");
            this.statusEl.textContent = "";
            return;
        }
        if (statusClass) {
            this.statusEl.classList.add(statusClass);
        }
        this.statusEl.textContent = message;
    },
});

export default publicWidget.registry.DentistClinicEventRequest;
